from django.apps import AppConfig


class DiscountsConfig(AppConfig):
    name = 'discounts'
